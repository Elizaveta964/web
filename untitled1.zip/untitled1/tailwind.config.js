/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "/*.{js,html}",
      "/dist/*.{js,html}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
